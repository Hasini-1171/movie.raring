RECALLROCKET - FRONTEND PROJECT

FILES
1. index.html  - page structure
2. style.css   - design and responsive layout
3. script.js   - flashcards, SM-2 scheduling, streaks, and LocalStorage

HOW TO RUN IN VS CODE
1. Extract this folder.
2. Open the RecallRocket_90plus folder in Visual Studio Code.
3. Make sure all three files are in the same folder.
4. Install the Live Server extension if it is not already installed.
5. Right-click index.html and choose "Open with Live Server".
6. The app opens in your browser.

IMPORTANT
- Run index.html. Do not run style.css or script.js directly.
- Keep the filenames exactly as shown.
- The project stores data in the browser's LocalStorage.
- The leaderboard uses sample/demo classmates. Real shared campus rankings need a backend and student accounts.
- This is a frontend-only implementation. It does not include a server, login system, or cloud database.

FEATURES
- Create and manage subject decks.
- Add custom question-and-answer flashcards.
- 3D flashcard flip interaction.
- SM-2 spaced repetition scheduling with grades 0-5 internally (the UI offers 1-5).
- Daily due-review queue.
- Keyboard shortcuts: Space to flip; 0-5 to rate after flipping.
- Study streak and memory points.
- Progress charts and deck completion indicators.
- Demo leaderboard.
- Responsive layout and dark mode.
