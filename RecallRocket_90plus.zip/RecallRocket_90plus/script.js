'use strict';

/* RecallRocket - frontend demonstration using LocalStorage.
   The leaderboard contains demo classmates; real shared rankings require a backend. */
const STORAGE_KEY = 'recallrocket_data_v2';
const THEME_KEY = 'recallrocket_theme_v2';
const DAY_MS = 24 * 60 * 60 * 1000;
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const todayKey = (date = new Date()) => {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};
const addDays = (dateString, days) => {
  const [y, m, d] = dateString.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  date.setDate(date.getDate() + days);
  return todayKey(date);
};
const escapeHTML = (value) => String(value).replace(/[&<>"']/g, (char) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
})[char]);
const makeId = () => (window.crypto && crypto.randomUUID)
  ? crypto.randomUUID()
  : `id-${Date.now()}-${Math.random().toString(16).slice(2)}`;

function createInitialData() {
  const today = todayKey();
  const examples = [
    { title: 'Data Structures', description: 'Build a strong foundation in core concepts.', color: 'violet', icon: '⌘', cards: [
      ['What is a data structure?', 'A way of organising and storing data so it can be used efficiently.'],
      ['What is an array?', 'An array stores elements of the same type in a sequence, usually accessed by index.'],
      ['What is a stack?', 'A linear data structure that follows LIFO: Last In, First Out.'],
      ['What is a queue?', 'A linear data structure that follows FIFO: First In, First Out.'],
      ['What is a linked list?', 'A sequence of nodes where each node stores data and a link to the next node.']
    ]},
    { title: 'Algorithms', description: 'Understand problem-solving step by step.', color: 'blue', icon: '⌘', cards: [
      ['What is an algorithm?', 'A finite, clear sequence of steps used to solve a problem.'],
      ['What is the time complexity of QuickSort on average?', 'O(n log n). Its worst-case time complexity is O(n²).'],
      ['What is binary search?', 'A search method that repeatedly divides a sorted search range in half.'],
      ['What does Big-O notation describe?', 'It describes how an algorithm’s resource use grows as input size increases.'],
      ['What is recursion?', 'A technique in which a function calls itself to solve smaller parts of a problem.']
    ]},
    { title: 'Computer Networks', description: 'Learn how devices communicate.', color: 'mint', icon: '⌁', cards: [
      ['What is a computer network?', 'A group of connected devices that communicate and share resources.'],
      ['What does IP stand for?', 'Internet Protocol.'],
      ['What is the role of a router?', 'It forwards data packets between different networks.']
    ]},
    { title: 'Python Basics', description: 'Revise the building blocks of Python.', color: 'orange', icon: '⌘', cards: [
      ['What is a variable in Python?', 'A named reference used to store a value.'],
      ['Which keyword defines a function in Python?', 'The def keyword.'],
      ['What is a list in Python?', 'An ordered, changeable collection that can contain multiple values.']
    ]}
  ];
  const decks = examples.map((deck) => ({
    id: makeId(), title: deck.title, description: deck.description, color: deck.color, icon: deck.icon,
    cards: deck.cards.map(([question, answer], index) => ({
      id: makeId(), question, answer, easeFactor: 2.5, interval: 0, repetitions: 0,
      nextReviewDate: today, createdAt: today, reviewCount: 0, lastGrade: null, order: index
    }))
  }));
  return { decks, reviews: [], activeDates: [], currentStreak: 0, bestStreak: 0, points: 0, totalReviewed: 0 };
}

function loadData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return createInitialData();
    const parsed = JSON.parse(raw);
    if (!parsed || !Array.isArray(parsed.decks) || !Array.isArray(parsed.reviews)) return createInitialData();
    parsed.activeDates = Array.isArray(parsed.activeDates) ? parsed.activeDates : [];
    parsed.currentStreak = Number(parsed.currentStreak) || 0;
    parsed.bestStreak = Number(parsed.bestStreak) || 0;
    parsed.points = Number(parsed.points) || 0;
    parsed.totalReviewed = Number(parsed.totalReviewed) || 0;
    parsed.decks = parsed.decks.map((deck) => ({
      ...deck,
      id: deck.id || makeId(),
      cards: Array.isArray(deck.cards) ? deck.cards.map((card) => ({
        id: card.id || makeId(), question: String(card.question || ''), answer: String(card.answer || ''),
        easeFactor: Math.max(1.3, Number(card.easeFactor) || 2.5), interval: Math.max(0, Number(card.interval) || 0),
        repetitions: Math.max(0, Number(card.repetitions) || 0), nextReviewDate: card.nextReviewDate || todayKey(),
        createdAt: card.createdAt || todayKey(), reviewCount: Math.max(0, Number(card.reviewCount) || 0),
        lastGrade: card.lastGrade ?? null
      })) : []
    }));
    return parsed;
  } catch (error) {
    console.error('Could not load saved RecallRocket data:', error);
    return createInitialData();
  }
}

let data = loadData();
let currentPage = 'dashboard';
let reviewQueue = [];
let reviewIndex = 0;
let isFlipped = false;
let toastTimer = null;

function saveData() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error('Could not save RecallRocket data:', error);
    showToast('Browser storage is full. Please export or remove some data.');
  }
}
function allCards() {
  return data.decks.flatMap((deck) => deck.cards.map((card) => ({ ...card, deckId: deck.id, deckTitle: deck.title, deckColor: deck.color })));
}
function dueCards() {
  const today = todayKey();
  return allCards().filter((card) => card.nextReviewDate <= today);
}
function showToast(message) {
  const toast = $('#toast');
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add('show');
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove('show'), 2500);
}
function getDeck(deckId) { return data.decks.find((deck) => deck.id === deckId); }
function getCard(deckId, cardId) {
  const deck = getDeck(deckId);
  return deck ? deck.cards.find((card) => card.id === cardId) : null;
}

function updateStreak(recordStudyDay = true) {
  const today = todayKey();
  if (recordStudyDay && !data.activeDates.includes(today)) data.activeDates.push(today);
  const uniqueDates = [...new Set(data.activeDates)].sort();
  data.activeDates = uniqueDates;
  // A streak remains current through today, or through yesterday until the day ends.
  let cursor = uniqueDates.includes(today) ? today : addDays(today, -1);
  let streak = 0;
  while (uniqueDates.includes(cursor)) {
    streak += 1;
    cursor = addDays(cursor, -1);
  }
  data.currentStreak = streak;
  data.bestStreak = Math.max(data.bestStreak, streak);
}

/* SM-2: grade is 0-5. Grades below 3 mean the answer was not recalled. */
function calculateSM2(card, grade) {
  const quality = Math.max(0, Math.min(5, Number(grade)));
  let easeFactor = Number(card.easeFactor) || 2.5;
  let repetitions = Number(card.repetitions) || 0;
  let interval = Number(card.interval) || 0;

  if (quality < 3) {
    repetitions = 0;
    interval = 1;
  } else {
    if (repetitions === 0) interval = 1;
    else if (repetitions === 1) interval = 6;
    else interval = Math.max(1, Math.round(interval * easeFactor));
    repetitions += 1;
  }

  const difference = 5 - quality;
  easeFactor = Math.max(1.3, easeFactor + (0.1 - difference * (0.08 + difference * 0.02)));
  return { easeFactor: Number(easeFactor.toFixed(2)), repetitions, interval, nextReviewDate: addDays(todayKey(), interval) };
}

function markCardReviewed(deckId, cardId, grade) {
  const card = getCard(deckId, cardId);
  if (!card) return;
  const result = calculateSM2(card, grade);
  Object.assign(card, result, { reviewCount: card.reviewCount + 1, lastGrade: grade });
  data.totalReviewed += 1;
  data.points += Math.max(1, grade) * 10;
  data.reviews.push({ date: todayKey(), deckId, cardId, grade, points: Math.max(1, grade) * 10 });
  updateStreak();
  saveData();
}

function showPage(pageName) {
  const validPages = ['dashboard', 'decks', 'review', 'progress', 'leaderboard'];
  if (!validPages.includes(pageName)) return;
  currentPage = pageName;
  $$('.page').forEach((page) => page.classList.toggle('active', page.id === `page-${pageName}`));
  $$('.nav-link[data-page]').forEach((button) => button.classList.toggle('active', button.dataset.page === pageName));
  const title = pageName.charAt(0).toUpperCase() + pageName.slice(1);
  $('#pageCrumb').textContent = pageName === 'decks' ? 'My decks' : pageName === 'progress' ? 'My progress' : title;
  $('#sidebar').classList.remove('open');
  if (pageName === 'dashboard') renderDashboard();
  if (pageName === 'decks') renderDecks();
  if (pageName === 'review') startReview();
  if (pageName === 'progress') renderProgress();
  if (pageName === 'leaderboard') renderLeaderboard();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function renderStats() {
  const cards = allCards();
  const due = dueCards().length;
  $('#statCards').textContent = cards.length;
  $('#statStreak').innerHTML = `${data.currentStreak} <em>days</em>`;
  $('#statReviewed').textContent = data.totalReviewed;
  $('#statPoints').textContent = data.points;
  $('#sideStreak').textContent = `${data.currentStreak} day streak`;
  $('#heroDue').textContent = due;
  $('#navDueCount').textContent = due;
  $('#reviewRemaining').textContent = `${due} cards due`;
}

function deckCompletion(deck) {
  if (!deck.cards.length) return 0;
  const learned = deck.cards.filter((card) => card.repetitions > 0).length;
  return Math.round((learned / deck.cards.length) * 100);
}
function deckCardHTML(deck) {
  const count = deck.cards.length;
  const due = deck.cards.filter((card) => card.nextReviewDate <= todayKey()).length;
  const progress = deckCompletion(deck);
  return `<article class="deck-card">
    <div class="deck-top"><div class="deck-icon ${escapeHTML(deck.color || 'violet')}">${escapeHTML(deck.icon || '▤')}</div><button class="more-btn" data-deck-menu="${escapeHTML(deck.id)}" aria-label="Deck options">···</button></div>
    <h3>${escapeHTML(deck.title)}</h3><p>${escapeHTML(deck.description || 'Your personal revision deck.')}</p>
    <div class="deck-meta"><span>${count} flashcard${count === 1 ? '' : 's'}</span><strong>${due} due today</strong></div>
    <div class="mini-track"><span style="width:${progress}%"></span></div>
    <div class="deck-meta" style="margin-top:6px"><span>Learning progress</span><strong>${progress}%</strong></div>
    <div class="deck-actions"><button class="small-action primary" data-add-card="${escapeHTML(deck.id)}">＋ Add card</button><button class="small-action" data-review-deck="${escapeHTML(deck.id)}">Study deck →</button></div>
  </article>`;
}
function renderDashboard() {
  renderStats();
  $('#dashboardDecks').innerHTML = data.decks.slice(0, 3).map(deckCardHTML).join('') || '<p class="muted">Create your first deck to get started.</p>';
  renderActivityChart($('#activityChart'));
}
function renderDecks() {
  const query = ($('#deckSearch').value || '').trim().toLowerCase();
  const decks = data.decks.filter((deck) => `${deck.title} ${deck.description}`.toLowerCase().includes(query));
  $('#deckCount').textContent = `${decks.length} deck${decks.length === 1 ? '' : 's'}`;
  $('#allDecks').innerHTML = decks.map(deckCardHTML).join('');
  $('#emptyDecks').classList.toggle('hidden', decks.length > 0);
  renderStats();
}
function renderActivityChart(container) {
  if (!container) return;
  const days = [];
  for (let offset = 6; offset >= 0; offset -= 1) {
    const date = addDays(todayKey(), -offset);
    const count = data.reviews.filter((review) => review.date === date).length;
    const label = new Date(`${date}T12:00:00`).toLocaleDateString(undefined, { weekday: 'short' });
    days.push({ date, count, label });
  }
  const max = Math.max(1, ...days.map((day) => day.count));
  container.innerHTML = days.map((day) => `<div class="chart-day" title="${day.count} cards reviewed"><div class="chart-bar" style="height:${Math.max(3, (day.count / max) * 100)}%"></div><small>${escapeHTML(day.label)}</small></div>`).join('');
}

function startReview(deckId = null) {
  const cards = dueCards();
  reviewQueue = deckId ? cards.filter((card) => card.deckId === deckId) : cards;
  reviewIndex = 0;
  isFlipped = false;
  $('#ratingArea').classList.remove('hidden');
  $('#reviewComplete').classList.add('hidden');
  $('#flashcardWrap').classList.remove('hidden');
  if (!reviewQueue.length) {
    $('#flashcardWrap').classList.add('hidden');
    $('#ratingArea').classList.add('hidden');
    $('#reviewComplete').classList.remove('hidden');
    $('#completeMessage').textContent = deckId ? 'There are no cards due in this deck. Great work!' : 'You have no cards due right now. Add new cards or come back when your next revision is scheduled.';
    $('#reviewProgressText').textContent = 'All caught up';
    $('#reviewProgressBar').style.width = '100%';
    $('#reviewRemaining').textContent = '0 cards due';
    return;
  }
  renderCurrentCard();
}
function renderCurrentCard() {
  const card = reviewQueue[reviewIndex];
  if (!card) return;
  isFlipped = false;
  $('#flashcard').classList.remove('flipped');
  $('#cardDeckName').textContent = card.deckTitle.toUpperCase();
  $('#cardQuestion').textContent = card.question;
  $('#cardAnswer').textContent = card.answer;
  $('#reviewProgressText').textContent = `Card ${reviewIndex + 1} of ${reviewQueue.length}`;
  $('#reviewProgressBar').style.width = `${(reviewIndex / reviewQueue.length) * 100}%`;
  $('#reviewRemaining').textContent = `${reviewQueue.length - reviewIndex} cards left`;
  $('#ratingArea').classList.remove('hidden');
  $('#flashcardWrap').classList.remove('hidden');
  $('#reviewComplete').classList.add('hidden');
}
function flipCard() {
  if (!reviewQueue[reviewIndex]) return;
  isFlipped = !isFlipped;
  $('#flashcard').classList.toggle('flipped', isFlipped);
}
function rateCurrentCard(grade) {
  if (!isFlipped) {
    showToast('Flip the card and check the answer first.');
    return;
  }
  const current = reviewQueue[reviewIndex];
  markCardReviewed(current.deckId, current.id, grade);
  reviewIndex += 1;
  renderStats();
  if (reviewIndex >= reviewQueue.length) {
    $('#flashcardWrap').classList.add('hidden');
    $('#ratingArea').classList.add('hidden');
    $('#reviewComplete').classList.remove('hidden');
    $('#reviewProgressText').textContent = 'Session completed';
    $('#reviewProgressBar').style.width = '100%';
    $('#reviewRemaining').textContent = 'Completed';
    $('#completeMessage').textContent = `You reviewed ${reviewQueue.length} card${reviewQueue.length === 1 ? '' : 's'} and earned ${reviewQueue.reduce((sum, card) => sum + (Number(card.lastGrade) || 0) * 10, 0)} memory points. Keep your ${data.currentStreak}-day streak going!`;
    renderDashboard();
  } else {
    renderCurrentCard();
  }
}

function renderProgress() {
  $('#progressReviewed').textContent = data.totalReviewed;
  $('#bestStreak').innerHTML = `${data.bestStreak} <em>days</em>`;
  $('#progressPoints').textContent = data.points;
  renderActivityChart($('#progressChart'));
  const list = $('#deckProgressList');
  list.innerHTML = data.decks.length ? data.decks.map((deck) => `<div class="deck-progress-row"><strong>${escapeHTML(deck.title)}</strong><div class="mini-track"><span style="width:${deckCompletion(deck)}%"></span></div><span>${deckCompletion(deck)}%</span></div>`).join('') : '<p class="muted">No decks created yet.</p>';
}
function renderLeaderboard() {
  const sample = [
    { name: 'Aarav', cards: 186, streak: 14, points: 1860, initial: 'A' },
    { name: 'Meera', cards: 154, streak: 11, points: 1540, initial: 'M' },
    { name: 'You', cards: data.totalReviewed, streak: data.currentStreak, points: data.points, initial: 'S', you: true },
    { name: 'Ishaan', cards: 96, streak: 7, points: 960, initial: 'I' },
    { name: 'Diya', cards: 82, streak: 5, points: 820, initial: 'D' }
  ].sort((a, b) => b.points - a.points || b.streak - a.streak || b.cards - a.cards);
  $('#leaderboardRows').innerHTML = sample.map((person, index) => `<div class="leader-row ${person.you ? 'you' : ''}"><div class="leader-person"><span class="rank">${index + 1}</span><span class="leader-avatar">${person.initial}</span>${person.name}${person.you ? ' (you)' : ''}</div><span>${person.cards}</span><span>${person.streak} days</span><strong>${person.points}</strong></div>`).join('');
}

function openModal(id) { $(`#${id}`).classList.remove('hidden'); }
function closeModal(id) { $(`#${id}`).classList.add('hidden'); }
function createDeck(event) {
  event.preventDefault();
  const title = $('#deckTitle').value.trim();
  if (!title) return showToast('Please enter a subject name.');
  if (data.decks.some((deck) => deck.title.toLowerCase() === title.toLowerCase())) return showToast('A deck with this name already exists.');
  data.decks.push({ id: makeId(), title, description: $('#deckDescription').value.trim() || 'Your personal revision deck.', color: $('#deckColor').value, icon: '✧', cards: [] });
  saveData();
  $('#deckForm').reset();
  closeModal('deckModal');
  renderDecks();
  renderDashboard();
  showToast('Your new deck is ready!');
}
function openCardModal(deckId) {
  if (!getDeck(deckId)) return;
  $('#cardDeckId').value = deckId;
  $('#cardForm').reset();
  $('#cardDeckId').value = deckId;
  openModal('cardModal');
}
function createCard(event) {
  event.preventDefault();
  const deckId = $('#cardDeckId').value;
  const deck = getDeck(deckId);
  const question = $('#newQuestion').value.trim();
  const answer = $('#newAnswer').value.trim();
  if (!deck) return showToast('Please choose a valid deck.');
  if (!question || !answer) return showToast('Please enter both a question and an answer.');
  deck.cards.push({ id: makeId(), question, answer, easeFactor: 2.5, interval: 0, repetitions: 0, nextReviewDate: todayKey(), createdAt: todayKey(), reviewCount: 0, lastGrade: null });
  saveData();
  closeModal('cardModal');
  renderDecks();
  renderDashboard();
  showToast('Flashcard added. It is ready for review!');
}
function handleDeckAction(event) {
  const addButton = event.target.closest('[data-add-card]');
  const reviewButton = event.target.closest('[data-review-deck]');
  const menuButton = event.target.closest('[data-deck-menu]');
  if (addButton) openCardModal(addButton.dataset.addCard);
  if (reviewButton) {
    showPage('review');
    startReview(reviewButton.dataset.reviewDeck);
  }
  if (menuButton) {
    const deck = getDeck(menuButton.dataset.deckMenu);
    if (!deck) return;
    const action = window.prompt(`Deck: ${deck.title}\nType R to rename or D to delete. Leave blank to cancel.`);
    if (!action) return;
    if (action.trim().toLowerCase() === 'r') {
      const newName = window.prompt('Enter the new deck name:', deck.title);
      if (newName && newName.trim()) {
        const cleanName = newName.trim();
        if (data.decks.some((item) => item.id !== deck.id && item.title.toLowerCase() === cleanName.toLowerCase())) return showToast('That deck name is already used.');
        deck.title = cleanName;
        saveData(); renderDecks(); renderDashboard(); showToast('Deck renamed.');
      }
    } else if (action.trim().toLowerCase() === 'd') {
      const confirmed = window.confirm(`Delete "${deck.title}" and all its flashcards?`);
      if (confirmed) {
        data.decks = data.decks.filter((item) => item.id !== deck.id);
        data.reviews = data.reviews.filter((review) => review.deckId !== deck.id);
        saveData(); renderDecks(); renderDashboard(); showToast('Deck deleted.');
      }
    }
  }
}

function setTheme(theme) {
  document.body.classList.toggle('dark', theme === 'dark');
  localStorage.setItem(THEME_KEY, theme);
  const icon = theme === 'dark' ? '☀' : '☾';
  $('#themeIcon').textContent = icon;
  $('#topThemeToggle').textContent = icon;
}
function toggleTheme() { setTheme(document.body.classList.contains('dark') ? 'light' : 'dark'); }

function bindEvents() {
  $$('.nav-link[data-page]').forEach((button) => button.addEventListener('click', () => showPage(button.dataset.page)));
  $$('[data-go]').forEach((button) => button.addEventListener('click', () => showPage(button.dataset.go)));
  $('#addDeckBtn').addEventListener('click', () => openModal('deckModal'));
  $('#deckForm').addEventListener('submit', createDeck);
  $('#cardForm').addEventListener('submit', createCard);
  $('#dashboardDecks').addEventListener('click', handleDeckAction);
  $('#allDecks').addEventListener('click', handleDeckAction);
  $('#deckSearch').addEventListener('input', renderDecks);
  $('#flashcard').addEventListener('click', flipCard);
  $$('.rating-btn').forEach((button) => button.addEventListener('click', () => rateCurrentCard(Number(button.dataset.grade))));
  $$('[data-close]').forEach((button) => button.addEventListener('click', () => closeModal(button.dataset.close)));
  $$('.modal-backdrop').forEach((backdrop) => backdrop.addEventListener('click', (event) => {
    if (event.target === backdrop) closeModal(backdrop.id);
  }));
  $('#themeToggle').addEventListener('click', toggleTheme);
  $('#topThemeToggle').addEventListener('click', toggleTheme);
  $('#mobileMenu').addEventListener('click', () => $('#sidebar').classList.toggle('open'));
  document.addEventListener('keydown', (event) => {
    const target = event.target;
    const typing = target && (['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName) || target.isContentEditable);
    if (event.key === 'Escape') $$('.modal-backdrop').forEach((modal) => closeModal(modal.id));
    if (typing || currentPage !== 'review') return;
    if (event.code === 'Space') { event.preventDefault(); flipCard(); }
    if (/^[0-5]$/.test(event.key)) rateCurrentCard(Number(event.key));
  });
}

function initialise() {
  updateStreak(false);
  saveData();
  $('#todayLabel').textContent = new Date().toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
  const savedTheme = localStorage.getItem(THEME_KEY);
  if (savedTheme === 'dark') setTheme('dark');
  bindEvents();
  renderDashboard();
  renderLeaderboard();
}

initialise();
